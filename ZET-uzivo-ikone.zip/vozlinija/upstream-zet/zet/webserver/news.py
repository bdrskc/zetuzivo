from dataclasses import dataclass
from email.message import Message
from email.utils import parsedate_to_datetime
from html.parser import HTMLParser
from typing import Any, Protocol, TypeAlias
from urllib.error import HTTPError
from urllib.parse import urljoin, urlparse
from urllib.request import HTTPRedirectHandler, Request, build_opener
from xml.etree import ElementTree
import datetime
import hashlib
import html
import json
import logging
import os
import re
import threading
import time


NewsJson: TypeAlias = dict[str, str | int | None]


class RssResponse(Protocol):
    def read(self, size: int = -1) -> bytes: ...

    def geturl(self) -> str: ...

NEWS_FETCH_INTERVAL_SECONDS: int = 5 * 60
RSS_FETCH_TIMEOUT_SECONDS: int = 15
RSS_FETCH_TOTAL_TIMEOUT_SECONDS: int = 20
MAX_RSS_RESPONSE_BYTES: int = 256 * 1024
RSS_READ_CHUNK_BYTES: int = 16 * 1024
MAX_RSS_ITEMS_PER_FEED: int = 100
DEFAULT_APP_NEWS_FILE: str = 'app_news.json'
MAX_APP_NEWS_FILE_BYTES: int = 64 * 1024
MAX_APP_NEWS_ITEMS: int = 30
RSS_FEEDS: tuple[tuple[str, str], ...] = (
    ('traffic', 'https://www.zet.hr/rss_promet.aspx'),
    ('news', 'https://www.zet.hr/rss_novosti.aspx'),
)
MAX_NEWS_ITEMS: int = 30
MAX_NEWS_TITLE_LENGTH: int = 250
MAX_NEWS_URL_LENGTH: int = 2048
MAX_NEWS_SUMMARY_SOURCE_LENGTH: int = 4096
MAX_NEWS_SUMMARY_HTML_LENGTH: int = 8192
MIN_NEWS_TIMESTAMP: int = 0
MAX_NEWS_TIMESTAMP: int = 4_102_444_800  # 2100-01-01
NEWS_SCHEMA_V1: int = 1
NEWS_SCHEMA_V2: int = 2

logger = logging.getLogger(__name__)


class HtmlTextExtractor(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.parts: list[str] = []

    def handle_data(self, data: str) -> None:
        self.parts.append(data)

    def text(self) -> str:
        return ' '.join(' '.join(self.parts).split())


def html_to_text(value: str) -> str:
    parser = HtmlTextExtractor()
    parser.feed(html.unescape(value))
    return parser.text()


ALLOWED_RSS_TAGS: set[str] = {
    'strong', 'b', 'em', 'i', 'br', 'p', 'ul', 'ol', 'li'}
DROP_CONTENT_RSS_TAGS: set[str] = {
    'iframe', 'object', 'script', 'style', 'template'}
BLOCK_RSS_TAGS: set[str] = {
    'article', 'blockquote', 'div', 'footer', 'h1', 'h2', 'h3', 'h4', 'h5',
    'h6', 'header', 'section'}
TRAILING_RSS_SPACE: re.Pattern[str] = re.compile(
    r'(?:[\s\u00a0]|<br>)+(?=(?:</(?:strong|b|em|i|p|ul|ol|li)>)*$)')


class SafeHtmlExtractor(HTMLParser):
    """Keep only harmless presentation tags from RSS descriptions."""
    def __init__(self) -> None:
        super().__init__()
        self.parts: list[str] = []
        self.open_tags: list[str] = []
        self.dropped_content_tag: str | None = None

    def handle_starttag(
            self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if self.dropped_content_tag is not None:
            return
        if tag in DROP_CONTENT_RSS_TAGS:
            self.dropped_content_tag = tag
            return
        if tag in BLOCK_RSS_TAGS:
            self._append_line_break()
        if tag == 'br':
            self.parts.append('<br>')
        elif tag in ALLOWED_RSS_TAGS:
            self.parts.append(f'<{tag}>')
            self.open_tags.append(tag)

    def handle_startendtag(
            self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if self.dropped_content_tag is not None:
            return
        if tag == 'br' or tag in BLOCK_RSS_TAGS:
            self.parts.append('<br>')

    def handle_endtag(self, tag: str) -> None:
        if self.dropped_content_tag is not None:
            if tag == self.dropped_content_tag:
                self.dropped_content_tag = None
            return
        if tag in BLOCK_RSS_TAGS:
            self._append_line_break()
        if tag not in self.open_tags:
            return
        # Close any allowed nested tags first, keeping the emitted fragment
        # balanced even if the source RSS has malformed nesting.
        while self.open_tags:
            open_tag = self.open_tags.pop()
            self.parts.append(f'</{open_tag}>')
            if open_tag == tag:
                return

    def handle_data(self, data: str) -> None:
        if self.dropped_content_tag is None:
            self.parts.append(html.escape(data))

    def _append_line_break(self) -> None:
        if self.parts and self.parts[-1] != '<br>':
            self.parts.append('<br>')

    def sanitized_html(self) -> str:
        while self.open_tags:
            self.parts.append(f'</{self.open_tags.pop()}>')
        value = ''.join(self.parts)
        while True:
            value, count = TRAILING_RSS_SPACE.subn('', value)
            if count == 0:
                return value


def sanitize_rss_html(value: str) -> str:
    try:
        parser = SafeHtmlExtractor()
        parser.feed(html.unescape(value))
        parser.close()
        return parser.sanitized_html()
    except Exception as e:
        logger.warning('Could not sanitize RSS HTML; using plain text: %s', e)
        return html.escape(html_to_text(value))


def limit_summary_html(value: str) -> str:
    if len(value) <= MAX_NEWS_SUMMARY_HTML_LENGTH:
        return value
    # Preserve the bound even for text that expands when escaped. Falling back
    # to text keeps the result safe and well-formed.
    return html.escape(html_to_text(value)[:MAX_NEWS_SUMMARY_HTML_LENGTH // 6])


def news_item_id(
        kind: str,
        published_at: int,
        title: str,
        summary_html: str,
        url: str | None,
) -> str:
    message = json.dumps(
        [kind, published_at, title, summary_html, url],
        ensure_ascii=False,
        separators=(',', ':'),
    ).encode()
    return hashlib.sha256(message).hexdigest()[:32]


def is_zet_url(value: str) -> bool:
    parsed = urlparse(value)
    return (parsed.scheme == 'https'
            and parsed.hostname in {'zet.hr', 'www.zet.hr'})


def is_https_url(value: str) -> bool:
    parsed = urlparse(value)
    return parsed.scheme == 'https' and parsed.hostname is not None


class ZetRedirectHandler(HTTPRedirectHandler):
    def redirect_request(
            self,
            req: Request,
            fp: Any,
            code: int,
            msg: str,
            headers: Message,
            newurl: str,
    ) -> Request | None:
        redirect_url = urljoin(req.full_url, newurl)
        if not is_zet_url(redirect_url):
            raise HTTPError(
                req.full_url, code, 'RSS redirect outside zet.hr', headers, fp)
        return super().redirect_request(
            req, fp, code, msg, headers, redirect_url)


RSS_OPENER = build_opener(ZetRedirectHandler)


def read_bounded_response(response: RssResponse) -> bytes:
    deadline = time.monotonic() + RSS_FETCH_TOTAL_TIMEOUT_SECONDS
    chunks: list[bytes] = []
    total_size = 0
    while True:
        if time.monotonic() > deadline:
            raise TimeoutError('RSS download exceeded total timeout')
        chunk = response.read(min(
            RSS_READ_CHUNK_BYTES,
            MAX_RSS_RESPONSE_BYTES + 1 - total_size,
        ))
        if not chunk:
            return b''.join(chunks)
        total_size += len(chunk)
        if total_size > MAX_RSS_RESPONSE_BYTES:
            raise ValueError('RSS response exceeds size limit')
        chunks.append(chunk)


@dataclass(frozen=True)
class NewsItem:
    id: str
    kind: str
    published_at: int
    title: str
    summary_html: str
    url: str | None

    def to_json(self) -> NewsJson:
        return {
            'id': self.id,
            'kind': self.kind,
            'publishedAt': self.published_at,
            'title': self.title,
            'summaryHtml': self.summary_html,
            'url': self.url,
        }


class NewsCache:
    def __init__(self, app_news_path: str | None = None) -> None:
        self._lock = threading.Lock()
        self._items_by_kind: dict[str, list[NewsItem]] = {
            'traffic': [], 'news': [], 'app': []}
        self._items_by_schema: dict[int, list[NewsItem]] = {
            NEWS_SCHEMA_V1: [], NEWS_SCHEMA_V2: []}
        self._versions_by_schema: dict[int, str] = {
            NEWS_SCHEMA_V1: '', NEWS_SCHEMA_V2: ''}
        self._fetched_at = 0
        if app_news_path is not None:
            self._app_news_path = app_news_path
            self._app_news_path_is_explicit = True
        elif 'ZET_APP_NEWS_FILE' in os.environ:
            self._app_news_path = os.environ['ZET_APP_NEWS_FILE']
            self._app_news_path_is_explicit = True
        else:
            self._app_news_path = DEFAULT_APP_NEWS_FILE
            self._app_news_path_is_explicit = False

    @staticmethod
    def _parse_feed(url: str, kind: str) -> list[NewsItem]:
        request = Request(url, headers={
            'User-Agent': 'zet.skoljka.org RSS reader (+https://github.com/ikicic/zet)',
        })
        with RSS_OPENER.open(
                request,
                timeout=min(
                    RSS_FETCH_TIMEOUT_SECONDS, RSS_FETCH_TOTAL_TIMEOUT_SECONDS),
        ) as response:
            if not is_zet_url(response.geturl()):
                raise ValueError('RSS response outside zet.hr')
            raw_feed = read_bounded_response(response)
        logger.info('Fetched %s RSS feed (%d bytes)', kind, len(raw_feed))
        root = ElementTree.fromstring(raw_feed)

        if root.tag != 'rss':
            raise ValueError('RSS document has unexpected root element')
        channel = root.find('channel')
        if channel is None:
            raise ValueError('RSS document has no channel element')

        items: list[NewsItem] = []
        # A syntactically valid channel with no items is a genuine empty feed
        # and intentionally replaces the previously cached category.
        item_nodes = channel.findall('item')
        if len(item_nodes) > MAX_RSS_ITEMS_PER_FEED:
            logger.warning('RSS feed has %d items; parsing first %d',
                           len(item_nodes), MAX_RSS_ITEMS_PER_FEED)
        for node in item_nodes[:MAX_RSS_ITEMS_PER_FEED]:
            title = html_to_text(
                node.findtext('title', default=''))[:MAX_NEWS_TITLE_LENGTH]
            link = node.findtext('link', default='').strip()
            published = node.findtext('pubDate', default='').strip()
            if (not title or not link or not published
                    or len(link) > MAX_NEWS_URL_LENGTH
                    or not is_zet_url(link)):
                continue
            try:
                published_at = int(parsedate_to_datetime(published).timestamp())
            except (TypeError, ValueError, IndexError):
                logger.warning('Skipping RSS item with invalid date: %s', published)
                continue
            if not MIN_NEWS_TIMESTAMP <= published_at <= MAX_NEWS_TIMESTAMP:
                logger.warning('Skipping RSS item with out-of-range date: %s',
                               published)
                continue
            summary_html = limit_summary_html(sanitize_rss_html(
                node.findtext(
                    'description', default='')[:MAX_NEWS_SUMMARY_SOURCE_LENGTH]))
            items.append(NewsItem(
                id=news_item_id(kind, published_at, title, summary_html, link),
                kind=kind,
                published_at=published_at,
                title=title,
                summary_html=summary_html,
                url=link,
            ))
        if item_nodes and not items:
            raise ValueError('RSS feed has items but none passed validation')
        return items

    @staticmethod
    def _parse_app_news(path: str) -> list[NewsItem]:
        with open(path, 'rb') as file:
            raw_data = file.read(MAX_APP_NEWS_FILE_BYTES + 1)
        if len(raw_data) > MAX_APP_NEWS_FILE_BYTES:
            raise ValueError('app news file exceeds size limit')

        raw_items = json.loads(raw_data)
        if not isinstance(raw_items, list):
            raise ValueError('app news file must contain a JSON array')
        if len(raw_items) > MAX_APP_NEWS_ITEMS:
            raise ValueError(
                f'app news file contains more than {MAX_APP_NEWS_ITEMS} items')

        items: list[NewsItem] = []
        allowed_keys = {'publishedAt', 'title', 'summary', 'url'}
        for index, raw_item in enumerate(raw_items):
            if not isinstance(raw_item, dict):
                raise ValueError(f'app news item {index} must be an object')
            unknown_keys = set(raw_item) - allowed_keys
            if unknown_keys:
                raise ValueError(
                    f'app news item {index} has unknown fields: '
                    f'{", ".join(sorted(unknown_keys))}')

            published = raw_item.get('publishedAt')
            title = raw_item.get('title')
            summary = raw_item.get('summary', '')
            url = raw_item.get('url')
            if not isinstance(published, str):
                raise ValueError(
                    f'app news item {index} publishedAt must be a string')
            if not isinstance(title, str) or not title.strip():
                raise ValueError(
                    f'app news item {index} title must be a non-empty string')
            if len(title) > MAX_NEWS_TITLE_LENGTH:
                raise ValueError(f'app news item {index} title is too long')
            if not isinstance(summary, str):
                raise ValueError(f'app news item {index} summary must be a string')
            if len(summary) > MAX_NEWS_SUMMARY_SOURCE_LENGTH:
                raise ValueError(f'app news item {index} summary is too long')
            if url is not None and (
                    not isinstance(url, str)
                    or len(url) > MAX_NEWS_URL_LENGTH
                    or not is_https_url(url)):
                raise ValueError(
                    f'app news item {index} url must be null or an HTTPS URL')

            try:
                published_datetime = datetime.datetime.fromisoformat(published)
            except ValueError as e:
                raise ValueError(
                    f'app news item {index} has invalid publishedAt') from e
            if (published_datetime.tzinfo is None
                    or published_datetime.utcoffset() is None):
                raise ValueError(
                    f'app news item {index} publishedAt must include a timezone')
            published_at = int(published_datetime.timestamp())
            if not MIN_NEWS_TIMESTAMP <= published_at <= MAX_NEWS_TIMESTAMP:
                raise ValueError(
                    f'app news item {index} publishedAt is out of range')

            title = ' '.join(title.split())
            summary_html = limit_summary_html(
                html.escape(summary).replace('\r\n', '\n')
                .replace('\r', '\n').replace('\n', '<br>'))
            items.append(NewsItem(
                id=news_item_id('app', published_at, title, summary_html, url),
                kind='app',
                published_at=published_at,
                title=title,
                summary_html=summary_html,
                url=url,
            ))
        return items

    def refresh(self) -> bool:
        fetched: dict[str, list[NewsItem]] = {}
        for kind, url in RSS_FEEDS:
            try:
                logger.info('Fetching %s RSS feed: %s', kind, url)
                fetched[kind] = self._parse_feed(url, kind)
            except Exception as e:
                logger.warning('Failed to fetch %s RSS feed (%s): %s',
                               kind, url, e)

        try:
            fetched['app'] = self._parse_app_news(self._app_news_path)
        except FileNotFoundError as e:
            if self._app_news_path_is_explicit:
                logger.warning('Failed to read app news file (%s): %s',
                               self._app_news_path, e)
            else:
                fetched['app'] = []
        except Exception as e:
            logger.warning('Failed to read app news file (%s): %s',
                           self._app_news_path, e)

        if not fetched:
            return False

        with self._lock:
            items_by_kind = dict(self._items_by_kind)
        items_by_kind.update(fetched)

        def combine(kinds: tuple[str, ...]) -> list[NewsItem]:
            combined = sorted(
                [item for kind in kinds for item in items_by_kind[kind]],
                key=lambda item: (item.published_at, item.id), reverse=True)
            unique = list(
                {item.id: item for item in reversed(combined)}.values())
            return list(reversed(unique))

        schema_v1_items = combine(('traffic', 'news'))[:MAX_NEWS_ITEMS]
        combined_items = combine(('traffic', 'news', 'app'))
        if os.environ.get('ZET_DEV') == '1':
            now = int(time.time())
            combined_items.insert(0, NewsItem(
                id=f'dev-news-{now}', kind='app', published_at=now,
                title='Testna obavijest',
                summary_html='<strong>Test:</strong> nova obavijest s poslužitelja.',
                url=None))
        schema_v2_items = combined_items[:MAX_NEWS_ITEMS]

        def items_version(version_items: list[NewsItem]) -> str:
            encoded_items = json.dumps(
                [item.to_json() for item in version_items],
                ensure_ascii=False, sort_keys=True,
                separators=(',', ':')).encode()
            return hashlib.sha256(encoded_items).hexdigest()[:16]

        items_by_schema = {
            NEWS_SCHEMA_V1: schema_v1_items,
            NEWS_SCHEMA_V2: schema_v2_items,
        }
        versions_by_schema = {
            schema: items_version(schema_items)
            for schema, schema_items in items_by_schema.items()
        }
        with self._lock:
            self._items_by_kind = items_by_kind
            changed = versions_by_schema != self._versions_by_schema
            self._items_by_schema = items_by_schema
            self._versions_by_schema = versions_by_schema
            self._fetched_at = int(time.time())
            if changed:
                logger.info('News changed: %d items in snapshot',
                            len(schema_v2_items))
            return changed

    def snapshot(
            self, schema: int = NEWS_SCHEMA_V1) -> tuple[str, str] | None:
        with self._lock:
            version = self._versions_by_schema[schema]
            items = list(self._items_by_schema[schema])
            if not version:
                return None
            fetched_at = self._fetched_at
        message = json.dumps({'type': 'news', 'version': version,
                              'fetchedAt': fetched_at,
                              'items': [item.to_json() for item in items]}, separators=(',', ':'))
        return version, message

    def status_message(self, schema: int = NEWS_SCHEMA_V1) -> str | None:
        with self._lock:
            version = self._versions_by_schema[schema]
            items = self._items_by_schema[schema]
            if not version:
                return None
            latest_at = items[0].published_at if items else None
        return json.dumps({'type': 'news-status', 'version': version,
                           'latestAt': latest_at}, separators=(',', ':'))
